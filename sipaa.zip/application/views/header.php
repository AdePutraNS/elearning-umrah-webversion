<header class="main-header">
  <!-- Logo -->
  <a href="/" class="logo">
    <!-- mini logo for sidebar mini 50x50 pixels -->
    <span class="logo-mini"> <img src="<?php echo base_url(); ?>dist/img/logo_umrah.png" class="img-circle" alt="User Image"></span>
    <!-- logo for regular state and mobile devices -->
    <span class="logo-lg"><img src="<?php echo base_url(); ?>dist/img/logo_umrah.png" class="img-circle" alt="User Image"><b> E </b>- Learning</span>
  </a>
  <!-- Header Navbar: style can be found in header.less -->
  <nav class="navbar navbar-static-top">


    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">
        <li class="dropdown messages-menu">
          <a href="<?php echo base_url(); ?>index.php/auth/login">Masuk</a>
        </li>
        <!-- User Account: style can be found in dropdown.less -->
        <li class="dropdown user user-menu">
          <a href="<?php echo base_url(); ?>index.php/auth/register">Daftar</a>
        </li>
        <!-- Control Sidebar Toggle Button -->

      </ul>
    </div>
  </nav>
</header>
